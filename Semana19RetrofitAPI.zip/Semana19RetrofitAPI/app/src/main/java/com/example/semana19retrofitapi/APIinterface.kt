package com.example.semana19retrofitapi

import android.telecom.Call
import retrofit2.http.GET

interface APIinterface {
    @GET("breeds")
    fun getCats(): Call<List<Cats>>

}