package com.example.semana19retrofitapi

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewParent
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.FieldPosition

class DataAdapter(private var datalist:List<Cats>, private val context:Context):
    RecyclerView.Adapter<DataAdapter.ViewHolder>() {

      override  fun onCreateViewHolder(parent: ViewGroup, viewType:Int):ViewHolder {
            return ViewHolder(
                LayoutInflater.from(context).inflate(
                    R.layout.list_item,
                    parent,
                    false
                )

            )
        }
   override fun getItemCount():{
        return datalist.size
    }
  override  fun onBindViewHolder(holder:ViewHolder, position:Int){
        val catsmodel = datalist.get(position)

      holder.txtName.text= catsmodel.name
      holder.txtOrigin.text= catsmodel.origin
      holder.txtDescription.text= catsmodel.description

      val imageURL = "http://cdn2.thecatapi.com/images/"
      Picasso.get().load(imageURL)into(holder.imgView)
    }
    class ViewHolder(itemLayoutView:View):RecyclerView.ViewHolder(itemLayoutView){

        var txtName: TextView = itemLayoutView.findViewById(R.id.name)
        var txtOrigin : TextView = itemLayoutView.findViewById(R.id.origin)
        var txtDescription : TextView = itemLayoutView.findViewById(R.id.description)
        var imgView : TextView = itemLayoutView.findViewById(R.id.imgCats)

    }
}

