package com.example.semana19retrofitapi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telecom.Call
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*
import javax.security.auth.callback.Callback

class MainActivity : AppCompatActivity() {
var datalist = ArrayList<Cats>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recycler_view.adapter= DataAdapter(datalist, this)
        recycler_view.layoutManager= LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)


        getData()

    }
    private fun getData(){
        val call: Call<List<Cats>> = ApiClient.getClient.getCats()
        call.enqueue(object:Callback<List<Cats>>)
    }
}